import { useCallback, useEffect, useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

/* Real photographs supplied for the Avirat Old Age Home website. */
import p1 from "@/assets/avirate-courtyard.jpg";
import p2 from "@/assets/avirate-food-thali.jpg";
import p3 from "@/assets/avirate-dining.jpg";
import p4 from "@/assets/avirate-food-2.jpg";
import p5 from "@/assets/avirate-daily-life.jpg";
import p6 from "@/assets/avirate-exterior.jpg";
import p7 from "@/assets/avirate-activities.jpg";
import p8 from "@/assets/avirate-garden.jpg";
import p9 from "@/assets/avirate-entrance.jpg";

export const GALLERY_IMAGES = [
  { src: p9, title: "Welcome to Avirat Old Age Home", category: "Our Home", alt: "Main entrance gate of Avirat Old Age Home in Vasai" },
  { src: p8, title: "A Calm Space to Relax", category: "Garden & Relaxation", alt: "Courtyard with a traditional swing, plants and seating at Avirat Old Age Home" },
  { src: p1, title: "A Peaceful Place to Call Home", category: "Our Home & Environment", alt: "Covered courtyard with seating, plants and a chess table at Avirat Old Age Home" },
  { src: p6, title: "A Warm and Welcoming Home", category: "Our Home", alt: "Exterior courtyard and building of Avirat Old Age Home with plants and bicycle" },
  { src: p3, title: "Sharing Meals, Sharing Moments", category: "Community & Togetherness", alt: "Residents sharing a meal together at Avirat Old Age Home" },
  { src: p5, title: "Everyday Moments Together", category: "Daily Life", alt: "Residents enjoying a meal together in the covered dining area" },
  { src: p2, title: "Wholesome Home-Cooked Meals", category: "Food & Nutrition", alt: "Home-style Indian meal served on a stainless-steel thali" },
  { src: p4, title: "Freshly Prepared with Care", category: "Food & Nutrition", alt: "Freshly prepared sabudana meal served in stainless-steel trays" },
  { src: p7, title: "Creativity in Every Corner", category: "Creativity & Activities", alt: "Handmade hanging decoration and artwork at Avirat Old Age Home" },
];

export function Gallery() {
  const [index, setIndex] = useState<number | null>(null);
  const close = useCallback(() => setIndex(null), []);
  const prev = useCallback(
    () => setIndex((i) => (i === null ? i : (i + GALLERY_IMAGES.length - 1) % GALLERY_IMAGES.length)),
    [],
  );
  const next = useCallback(
    () => setIndex((i) => (i === null ? i : (i + 1) % GALLERY_IMAGES.length)),
    [],
  );

  useEffect(() => {
    if (index === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [index, close, prev, next]);

  return (
    <>
      <div className="columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4">
        {GALLERY_IMAGES.map((img, i) => (
          <button
            key={img.src}
            type="button"
            onClick={() => setIndex(i)}
            className="reveal reveal-scale group block w-full overflow-hidden rounded-xl border border-border bg-card shadow-soft transition-shadow duration-500 hover:shadow-lift"
            style={{ transitionDelay: `${i * 60}ms` }}
            aria-label={`Open image: ${img.alt}`}
          >
            <span className="relative block overflow-hidden">
              <img
                src={img.src}
                alt={img.alt}
                loading="lazy"
                className="w-full transition-transform duration-[900ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.06]"
              />
              <span className="absolute inset-0 bg-primary/0 transition-colors duration-500 group-hover:bg-primary/15" />
            </span>
          </button>
        ))}
      </div>

      {index !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Image viewer"
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 backdrop-blur-sm"
          style={{ backgroundColor: "oklch(0.24 0.011 165 / 0.94)" }}
          onClick={close}
        >
          <button
            type="button"
            onClick={close}
            aria-label="Close image viewer"
            className="absolute top-4 right-4 grid h-11 w-11 place-items-center rounded-full bg-card/15 text-secondary transition-colors hover:bg-card/30"
          >
            <X className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              prev();
            }}
            aria-label="Previous image"
            className="absolute left-3 grid h-11 w-11 place-items-center rounded-full bg-card/15 text-secondary transition-colors hover:bg-card/30 sm:left-6"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <figure onClick={(e) => e.stopPropagation()} className="max-h-full">
            <img
              src={GALLERY_IMAGES[index]?.src}
              alt={GALLERY_IMAGES[index]?.alt ?? ""}
              className="mx-auto max-h-[76vh] w-auto rounded-lg object-contain shadow-lift"
            />
            <figcaption className="mt-4 text-center text-sm text-secondary/80">
              {GALLERY_IMAGES[index]?.title} · {GALLERY_IMAGES[index]?.category} · {index + 1} / {GALLERY_IMAGES.length}
            </figcaption>
          </figure>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              next();
            }}
            aria-label="Next image"
            className="absolute right-3 grid h-11 w-11 place-items-center rounded-full bg-card/15 text-secondary transition-colors hover:bg-card/30 sm:right-6"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
      )}
    </>
  );
}
