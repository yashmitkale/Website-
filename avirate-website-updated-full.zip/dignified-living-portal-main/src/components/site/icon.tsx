import {
  Heart,
  Crown,
  Handshake,
  ShieldCheck,
  Users,
  Leaf,
  BedDouble,
  UtensilsCrossed,
  Stethoscope,
  Clock,
  Sparkles,
  Gamepad2,
  Flame,
  Siren,
  type LucideIcon,
} from "lucide-react";

const map: Record<string, LucideIcon> = {
  heart: Heart,
  crown: Crown,
  handshake: Handshake,
  shield: ShieldCheck,
  users: Users,
  leaf: Leaf,
  bed: BedDouble,
  utensils: UtensilsCrossed,
  stethoscope: Stethoscope,
  clock: Clock,
  sparkles: Sparkles,
  gamepad: Gamepad2,
  candle: Flame,
  siren: Siren,
};

export function Icon({ name, className }: { name: string; className?: string }) {
  const Cmp = map[name] ?? Heart;
  return <Cmp className={className} aria-hidden="true" strokeWidth={1.5} />;
}