import { useState, type FormEvent } from "react";

/**
 * Static contact form. It does NOT send email yet — submissions are held in
 * component state only. To connect a backend later, replace the body of
 * `handleSubmit` with a fetch() to your endpoint or form service.
 */
export function ContactForm() {
  const [status, setStatus] = useState<"idle" | "done">("idle");

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // TODO (backend): send the form data to an endpoint or form service.
    setStatus("done");
  };

  const field =
    "w-full rounded-lg border border-border bg-card px-4 py-3 text-base text-foreground transition-all duration-300 placeholder:text-muted-foreground/70 focus:border-sage focus:ring-2 focus:ring-sage/30 focus:outline-none";

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate={false}>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="cf-name" className="mb-1.5 block text-sm font-medium">
            Full name
          </label>
          <input id="cf-name" name="name" type="text" required autoComplete="name" className={field} placeholder="Your name" />
        </div>
        <div>
          <label htmlFor="cf-phone" className="mb-1.5 block text-sm font-medium">
            Phone
          </label>
          <input id="cf-phone" name="phone" type="tel" autoComplete="tel" className={field} placeholder="Your phone number" />
        </div>
      </div>
      <div>
        <label htmlFor="cf-email" className="mb-1.5 block text-sm font-medium">
          Email
        </label>
        <input id="cf-email" name="email" type="email" required autoComplete="email" className={field} placeholder="you@example.com" />
      </div>
      <div>
        <label htmlFor="cf-message" className="mb-1.5 block text-sm font-medium">
          Message
        </label>
        <textarea id="cf-message" name="message" rows={5} required className={field} placeholder="How can we help?" />
      </div>

      <button
        type="submit"
        className="w-full rounded-full bg-primary px-6 py-3.5 text-base font-medium text-primary-foreground transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lift sm:w-auto"
      >
        Send message
      </button>

      <p aria-live="polite" className="text-sm text-muted-foreground">
        {status === "done"
          ? "Thank you — your details were captured in this page. Message delivery is not connected yet, so please also call us on the numbers listed."
          : "This form is not connected to a mail service yet. Please call or email us directly for anything urgent."}
      </p>
    </form>
  );
}