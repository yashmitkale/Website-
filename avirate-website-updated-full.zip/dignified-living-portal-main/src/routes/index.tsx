import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowUp, ArrowRight, Phone, Mail, MapPin, Clock, Quote } from "lucide-react";

import { SiteNav, NAV_LINKS } from "@/components/site/site-nav";
import { Icon } from "@/components/site/icon";
import { Counter } from "@/components/site/counter";
import { Gallery } from "@/components/site/gallery";
import { ContactForm } from "@/components/site/contact-form";
import { useScrollReveal } from "@/hooks/use-reveal";
import {
  org,
  hero,
  intro,
  mission,
  values,
  stats,
  story,
  facilities,
  activities,
  testimonials,
  getInvolved,
  accommodations,
  mealRoutine,
  leadership,
} from "@/content/site-content";

import heroPhoto from "@/assets/avirate-entrance.jpg";
import aboutPhoto from "@/assets/avirate-dining.jpg";
import gatePhoto from "@/assets/avirate-entrance.jpg";

const TITLE = "Avirat Old Age Home — Vasai";
const DESCRIPTION =
  "Avirat Old Age Home in Vasai-Virar is a caring, peaceful home for senior citizens, with companionship, home-style meals and a welcoming community.";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
});

/* ---------- Small building blocks ---------- */

function Section({
  id,
  className = "",
  children,
}: {
  id?: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className={`scroll-mt-24 px-5 py-20 sm:px-8 md:py-28 ${className}`}>
      <div className="mx-auto max-w-[80rem]">{children}</div>
    </section>
  );
}

function SectionHeading({
  eyebrow,
  title,
  intro: introText,
  align = "left",
  tone = "dark",
}: {
  eyebrow: string;
  title: string;
  intro?: string;
  align?: "left" | "center";
  tone?: "dark" | "light";
}) {
  return (
    <div
      className={`reveal max-w-2xl ${align === "center" ? "mx-auto text-center" : ""} ${
        tone === "light" ? "text-primary-foreground" : ""
      }`}
    >
      <span className={`eyebrow ${align === "center" ? "justify-center" : ""}`}>{eyebrow}</span>
      <h2
        className={`mt-5 text-[clamp(2rem,5vw,3.25rem)] leading-[1.08] font-semibold ${
          tone === "light" ? "text-primary-foreground" : "text-primary"
        }`}
      >
        {title}
      </h2>
      {introText && (
        <p
          className={`mt-5 text-[1.0625rem] leading-relaxed ${
            tone === "light" ? "text-primary-foreground/80" : "text-muted-foreground"
          }`}
        >
          {introText}
        </p>
      )}
    </div>
  );
}

function BackToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 700);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <button
      type="button"
      aria-label="Back to top"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className={`fixed right-5 bottom-5 z-40 grid h-12 w-12 place-items-center rounded-full bg-primary text-primary-foreground shadow-lift transition-all duration-500 ${
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
      }`}
    >
      <ArrowUp className="h-5 w-5" />
    </button>
  );
}

/* ---------- Page ---------- */

function Index() {
  useScrollReveal();

  return (
    <div className="min-h-screen overflow-x-clip bg-background">
      <SiteNav />
      <main>
        {/* ============================== HERO ============================== */}
        <section id="home" className="relative overflow-hidden pt-28 pb-16 md:pt-36 md:pb-24">
          <div className="pointer-events-none absolute -top-32 -right-24 h-[26rem] w-[26rem] rounded-full bg-secondary/60 blur-3xl" />
          <div className="pointer-events-none absolute top-1/3 -left-32 h-80 w-80 rounded-full bg-sage/20 blur-3xl" />

          <div className="relative mx-auto grid max-w-[80rem] items-center gap-12 px-5 sm:px-8 lg:grid-cols-[1.05fr_1fr] lg:gap-16">
            <div>
              <span className="reveal eyebrow">{hero.eyebrow}</span>
              <h1
                className="reveal mt-6 text-[clamp(2.5rem,7vw,4.5rem)] leading-[1.03] font-semibold text-primary"
                style={{ transitionDelay: "80ms" }}
              >
                {hero.headline}
              </h1>
              <p
                className="reveal mt-6 max-w-xl text-[1.0625rem] leading-relaxed text-muted-foreground md:text-lg"
                style={{ transitionDelay: "160ms" }}
              >
                {hero.body}
              </p>
              <div className="reveal mt-9 flex flex-wrap gap-3" style={{ transitionDelay: "240ms" }}>
                <a
                  href="#about"
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-base font-medium text-primary-foreground transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lift"
                >
                  {hero.primaryCta}
                  <ArrowRight className="h-4 w-4" />
                </a>
                <a
                  href={org.mapsLink}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full border border-primary/25 px-7 py-3.5 text-base font-medium text-primary transition-all duration-300 hover:-translate-y-0.5 hover:bg-secondary"
                >
                  {hero.secondaryCta}
                </a>
              </div>
              <p
                className="reveal mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground"
                style={{ transitionDelay: "320ms" }}
              >
                <span className="inline-flex items-center gap-2">
                  <Phone className="h-4 w-4 text-accent" aria-hidden="true" />
                  <a href={`tel:${org.phone.replace(/\s/g, "")}`} className="hover:text-primary">
                    {org.phone}
                  </a>
                </span>
                <span className="inline-flex items-center gap-2">
                  <Phone className="h-4 w-4 text-accent" aria-hidden="true" />
                  <a href={`tel:${org.phoneAlt.replace(/\s/g, "")}`} className="hover:text-primary">
                    {org.phoneAlt}
                  </a>
                </span>
              </p>
            </div>

            <div className="reveal reveal-right relative" style={{ transitionDelay: "160ms" }}>
              <div className="absolute -top-5 -left-5 hidden h-40 w-40 rounded-tl-[3rem] border-t border-l border-accent/40 sm:block" />
              <img
                src={heroPhoto}
                alt="Main entrance of Avirat Old Age Home with the Avirat signboard"
                className="relative w-full rounded-[1.75rem] object-cover shadow-lift"
              />
              <div className="absolute -bottom-6 left-4 rounded-xl border border-border bg-card px-5 py-4 shadow-soft sm:left-8">
                <p className="font-display text-2xl font-semibold text-primary">24/7</p>
                <p className="text-xs tracking-[0.14em] text-muted-foreground uppercase">
                  Care & Companionship
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ============================== INTRO ============================== */}
        <Section id="about">
          <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
            <div className="reveal reveal-left relative order-2 lg:order-1">
              <img
                src={aboutPhoto}
                alt="Residents sharing a meal together at Avirat Old Age Home"
                loading="lazy"
                className="w-full rounded-[1.5rem] object-cover shadow-soft"
              />
              <div className="absolute -right-3 -bottom-6 max-w-[15rem] rounded-xl bg-primary px-5 py-4 text-primary-foreground shadow-lift sm:-right-6">
                <p className="text-sm leading-relaxed">{intro.highlight}</p>
              </div>
            </div>

            <div className="order-1 lg:order-2">
              <SectionHeading eyebrow={intro.eyebrow} title={intro.heading} />
              <div className="mt-6 space-y-4">
                {intro.body.map((p, i) => (
                  <p
                    key={i}
                    className="reveal text-[1.0625rem] leading-relaxed text-muted-foreground"
                    style={{ transitionDelay: `${80 + i * 80}ms` }}
                  >
                    {p}
                  </p>
                ))}
              </div>
              <a
                href="#our-home"
                className="reveal mt-8 inline-flex items-center gap-2 border-b border-accent pb-1 font-medium text-primary transition-colors hover:text-accent"
              >
                Read our story
                <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Leadership */}
          <div className="mt-16 grid gap-6 sm:grid-cols-2">
            {leadership.map((person, i) => (
              <article
                key={person.name}
                className="reveal rounded-2xl border border-border bg-card p-7 shadow-soft"
                style={{ transitionDelay: `${i * 90}ms` }}
              >
                <p className="text-xs font-semibold tracking-[0.2em] text-accent uppercase">
                  {person.role}
                </p>
                <h3 className="mt-2 font-display text-2xl font-semibold text-primary">
                  {person.name}
                </h3>
                <p className="mt-3 leading-relaxed text-muted-foreground">{person.body}</p>
              </article>
            ))}
          </div>
        </Section>

        {/* ========================= MISSION / VISION ========================= */}
        <Section className="bg-secondary/40">
          <SectionHeading
            eyebrow="What guides us"
            title="Our mission, vision and values."
            align="center"
          />

          <div className="mt-14 grid gap-6 md:grid-cols-2">
            {[
              { label: "Our Mission", text: mission.mission },
              { label: "Our Vision", text: mission.vision },
            ].map((block, i) => (
              <article
                key={block.label}
                className="reveal rounded-2xl border border-border bg-card p-8 shadow-soft transition-all duration-500 hover:-translate-y-1 hover:shadow-lift md:p-10"
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <h3 className="font-display text-2xl font-semibold text-primary">{block.label}</h3>
                <span className="mt-4 block h-px w-12 bg-accent/60" />
                <p className="mt-5 leading-relaxed text-muted-foreground">{block.text}</p>
              </article>
            ))}
          </div>

          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {values.map((v, i) => (
              <article
                key={v.title}
                className="reveal group rounded-2xl border border-border bg-card p-6 shadow-soft transition-all duration-500 hover:-translate-y-1 hover:border-sage/50 hover:shadow-lift"
                style={{ transitionDelay: `${i * 70}ms` }}
              >
                <span className="grid h-11 w-11 place-items-center rounded-full bg-secondary text-primary transition-colors duration-500 group-hover:bg-primary group-hover:text-primary-foreground">
                  <Icon name={v.icon} className="h-5 w-5" />
                </span>
                <h3 className="mt-5 font-display text-xl font-semibold text-primary">{v.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{v.body}</p>
              </article>
            ))}
          </div>
        </Section>

        {/* ============================ STATISTICS ============================ */}
        <section className="paper-texture bg-primary px-5 py-16 sm:px-8 md:py-20">
          <div className="mx-auto grid max-w-[80rem] gap-10 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((s, i) => (
              <div
                key={s.label}
                className="reveal text-center"
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <p className="font-display text-[clamp(2.5rem,6vw,3.5rem)] leading-none font-semibold text-primary-foreground">
                  <Counter value={s.value} suffix={s.suffix} />
                </p>
                <p className="mt-3 text-xs tracking-[0.2em] text-primary-foreground/70 uppercase">
                  {s.label}
                </p>
              </div>
            ))}
          </div>
          <p className="mx-auto mt-10 max-w-2xl text-center text-xs text-primary-foreground/50">
            Two locations across Vasai-Virar · Indicative charges {org.pricing}
          </p>
        </section>

        {/* ============================ OUR HOME ============================ */}
        <Section id="our-home">
          <SectionHeading
            eyebrow="Our home"
            title="A story told one day at a time."
            intro={story.philosophy}
          />

          <ol className="mt-14 space-y-0 border-l border-border pl-6 sm:pl-10">
            {story.timeline.map((item, i) => (
              <li
                key={i}
                className="reveal reveal-left relative pb-10 last:pb-0"
                style={{ transitionDelay: `${i * 90}ms` }}
              >
                <span className="absolute top-1.5 -left-[1.85rem] h-3 w-3 rounded-full border-2 border-accent bg-background sm:-left-[2.85rem]" />
                <p className="text-xs font-semibold tracking-[0.2em] text-accent uppercase">
                  {item.year}
                </p>
                <h3 className="mt-2 font-display text-2xl font-semibold text-primary">
                  {item.title}
                </h3>
                <p className="mt-2 max-w-2xl leading-relaxed text-muted-foreground">{item.body}</p>
              </li>
            ))}
          </ol>
        </Section>

        {/* ============================ FACILITIES ============================ */}
        <Section id="facilities" className="bg-secondary/40">
          <SectionHeading
            eyebrow="Facilities"
            title="Everything a comfortable day needs."
            intro="Practical, well-maintained spaces and services designed around the routines of older adults."
          />
          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {facilities.map((f, i) => (
              <article
                key={f.title}
                className="reveal group rounded-2xl border border-border bg-card p-6 shadow-soft transition-all duration-500 hover:-translate-y-1 hover:shadow-lift"
                style={{ transitionDelay: `${(i % 3) * 80}ms` }}
              >
                <span className="inline-grid h-11 w-11 place-items-center rounded-xl bg-secondary text-primary transition-transform duration-500 group-hover:scale-105">
                  <Icon name={f.icon} className="h-5 w-5" />
                </span>
                <h3 className="mt-5 font-display text-xl font-semibold text-primary">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
              </article>
            ))}
          </div>
        </Section>

        {/* ======================= ACCOMMODATION & FEES ======================= */}
        <Section id="rooms">
          <SectionHeading
            eyebrow="Accommodation"
            title="Rooms, dormitory and monthly charges."
            intro="Two ways to stay, both with the same meals, medical supervision and 24/7 caretaker support."
          />

          <div className="mt-14 grid gap-6 lg:grid-cols-2">
            {accommodations.map((room, i) => (
              <article
                key={room.title}
                className="reveal flex h-full flex-col rounded-2xl border border-border bg-card p-8 shadow-soft transition-all duration-500 hover:-translate-y-1 hover:shadow-lift"
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <span className="grid h-12 w-12 place-items-center rounded-full bg-secondary text-primary">
                  <Icon name={room.icon} className="h-5 w-5" />
                </span>
                <h3 className="mt-5 font-display text-2xl font-semibold text-primary">
                  {room.title}
                </h3>
                <p className="mt-3 leading-relaxed text-muted-foreground">{room.body}</p>
                <ul className="mt-6 grid gap-2 border-t border-border pt-5 text-sm text-muted-foreground sm:grid-cols-2">
                  {room.points.map((point) => (
                    <li key={point} className="flex items-start gap-2">
                      <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                      {point}
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>

          <div className="reveal mt-6 flex flex-col gap-4 rounded-2xl bg-primary px-8 py-7 text-primary-foreground sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-semibold tracking-[0.2em] text-primary-foreground/60 uppercase">
                Indicative monthly charges
              </p>
              <p className="mt-2 font-display text-3xl font-semibold">{org.pricing}</p>
              <p className="mt-2 text-sm text-primary-foreground/70">
                Final charges depend on room type and the level of care required. Daycare and
                short-stay options are also available.
              </p>
            </div>
            <a
              href={`tel:${org.phone.replace(/\s/g, "")}`}
              className="inline-flex shrink-0 items-center gap-2 self-start rounded-full bg-primary-foreground px-6 py-3 font-medium text-primary transition-transform duration-300 hover:-translate-y-0.5"
            >
              <Phone className="h-4 w-4" /> Call {org.phone}
            </a>
          </div>

          {/* Meals */}
          <div className="mt-16">
            <h3 className="reveal font-display text-2xl font-semibold text-primary">
              A day of meals, cooked fresh on the stove
            </h3>
            <p className="reveal mt-2 max-w-2xl leading-relaxed text-muted-foreground">
              Pure vegetarian and non-vegetarian plans, with special preparation for residents on
              medical diets.
            </p>
            <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {mealRoutine.map((meal, i) => (
                <li
                  key={meal.title}
                  className="reveal rounded-xl border border-border bg-card p-6 shadow-soft"
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <p className="text-xs tracking-[0.18em] text-accent uppercase">{meal.time}</p>
                  <p className="mt-2 font-display text-xl font-semibold text-primary">
                    {meal.title}
                  </p>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{meal.body}</p>
                </li>
              ))}
            </ol>
          </div>
        </Section>

        {/* ============================ ACTIVITIES ============================ */}
        <Section id="activities">
          <SectionHeading
            eyebrow="Daily life"
            title="Days with rhythm, company and purpose."
            intro="A gentle weekly routine that leaves room for rest, friendship and the occasional celebration."
          />
          <ul className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {activities.map((a, i) => (
              <li
                key={a.title}
                className="reveal reveal-scale group relative overflow-hidden rounded-xl border border-border bg-card p-6 transition-all duration-500 hover:-translate-y-1 hover:border-sage/60 hover:shadow-soft"
                style={{ transitionDelay: `${(i % 5) * 70}ms` }}
              >
                <span className="absolute inset-x-0 top-0 h-0.5 origin-left scale-x-0 bg-accent transition-transform duration-500 group-hover:scale-x-100" />
                <p className="font-display text-lg font-semibold text-primary">{a.title}</p>
                <p className="mt-1 text-xs tracking-[0.16em] text-muted-foreground uppercase">
                  {a.time}
                </p>
              </li>
            ))}
          </ul>
        </Section>

        {/* =========================== TESTIMONIALS =========================== */}
        {testimonials.length > 0 && (
          <Section className="bg-primary">
            <SectionHeading
              eyebrow="Voices"
              title="Stories from our home."
              intro="Real experiences from residents, families and visitors."
              align="center"
              tone="light"
            />
            <div className="mt-14 grid gap-6 lg:grid-cols-3">
              {testimonials.map((t, i) => (
                <figure
                  key={i}
                  className="reveal flex h-full flex-col rounded-2xl border border-primary-foreground/12 bg-primary-foreground/6 p-8 backdrop-blur-sm transition-transform duration-500 hover:-translate-y-1"
                  style={{ transitionDelay: `${i * 100}ms` }}
                >
                  <Quote className="h-7 w-7 text-accent" aria-hidden="true" />
                  <blockquote className="mt-5 flex-1 leading-relaxed text-primary-foreground/85">
                    {t.quote}
                  </blockquote>
                  <figcaption className="mt-6 flex items-center gap-3 border-t border-primary-foreground/12 pt-5">
                    <span
                      aria-hidden="true"
                      className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-primary-foreground/15 font-display text-sm text-primary-foreground"
                    >
                      ★
                    </span>
                    <span>
                      <span className="block font-medium text-primary-foreground">{t.name}</span>
                      <span className="block text-sm text-primary-foreground/60">{t.detail}</span>
                    </span>
                  </figcaption>
                </figure>
              ))}
            </div>
          </Section>
        )}

        {/* ============================== GALLERY ============================== */}
        <Section id="gallery">
          <SectionHeading
            eyebrow="Gallery"
            title="Moments from everyday life."
            intro="Select any photograph to open it. Use the arrow keys to browse and Escape to close."
          />
          <div className="mt-14">
            <Gallery />
          </div>
        </Section>

        {/* ============================ GET INVOLVED ============================ */}
        <Section id="get-involved" className="bg-secondary/40">
          <SectionHeading
            eyebrow="Get involved"
            title="Admissions, daycare and visits."
            align="center"
          />
          <div className="mt-14 grid gap-6 lg:grid-cols-3">
            {getInvolved.map((item, i) => (
              <article
                key={item.title}
                className="reveal flex h-full flex-col rounded-2xl border border-border bg-card p-8 shadow-soft transition-all duration-500 hover:-translate-y-1 hover:shadow-lift"
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <span className="grid h-12 w-12 place-items-center rounded-full bg-accent/12 text-accent">
                  <Icon name={item.icon} className="h-5 w-5" />
                </span>
                <h3 className="mt-5 font-display text-2xl font-semibold text-primary">
                  {item.title}
                </h3>
                <p className="mt-3 flex-1 leading-relaxed text-muted-foreground">{item.body}</p>
                <a
                  href="#contact"
                  className="mt-6 inline-flex items-center gap-2 border-b border-accent pb-1 self-start font-medium text-primary transition-colors hover:text-accent"
                >
                  {item.cta}
                  <ArrowRight className="h-4 w-4" />
                </a>
              </article>
            ))}
          </div>
        </Section>

        {/* ============================== CONTACT ============================== */}
        <Section id="contact">
          <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
            <div>
              <SectionHeading
                eyebrow="Contact"
                title="Come and see the home."
                intro="Visits are welcome at any hour. Call ahead so Archana or Vijay can set aside time to show you around properly."
              />
              <ul className="mt-10 space-y-5">
                <li className="reveal flex gap-4">
                  <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
                  <span>
                    <span className="block font-medium text-primary">
                      {org.name} — main home
                    </span>
                    <span className="text-muted-foreground">{org.address}</span>
                    <a
                      href={org.mapsLink}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-3 inline-flex items-center rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-transform hover:-translate-y-0.5"
                    >
                      Get Directions
                    </a>
                  </span>
                </li>
                <li className="reveal flex gap-4" style={{ transitionDelay: "40ms" }}>
                  <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
                  <span>
                    <span className="block font-medium text-primary">Extended facility</span>
                    <span className="text-muted-foreground">{org.addressSecondary}</span>
                  </span>
                </li>
                <li className="reveal flex gap-4" style={{ transitionDelay: "80ms" }}>
                  <Phone className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
                  <span className="flex flex-col">
                    <a href={`tel:${org.phone.replace(/\s/g, "")}`} className="hover:text-accent">
                      {org.phone}
                    </a>
                    <a href={`tel:${org.phoneAlt.replace(/\s/g, "")}`} className="hover:text-accent">
                      {org.phoneAlt}
                    </a>
                    <span className="text-sm text-muted-foreground">{org.contactPersons}</span>
                  </span>
                </li>
                {org.email && (
                  <li className="reveal flex gap-4" style={{ transitionDelay: "160ms" }}>
                    <Mail className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
                    <a href={`mailto:${org.email}`} className="text-muted-foreground hover:text-accent">{org.email}</a>
                  </li>
                )}
                <li className="reveal flex gap-4" style={{ transitionDelay: "240ms" }}>
                  <Clock className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
                  <span className="text-muted-foreground">{org.hours}</span>
                </li>
              </ul>

              <div className="reveal mt-8 overflow-hidden rounded-2xl border border-border shadow-soft">
                <iframe
                  src={org.mapEmbed}
                  title={`Map showing ${org.name} in Vasai West`}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="h-64 w-full border-0"
                />
              </div>

              <img
                src={gatePhoto}
                alt="The signboard and main gate of Avirat Old Age Home in Vasai West"
                loading="lazy"
                className="reveal mt-6 w-full rounded-2xl object-cover shadow-soft"
              />
            </div>

            <div className="reveal reveal-right rounded-2xl border border-border bg-card p-6 shadow-soft sm:p-10">
              <h3 className="font-display text-2xl font-semibold text-primary">Send us a message</h3>
              <p className="mt-2 mb-6 text-sm text-muted-foreground">
                Enquiries about admission, volunteering or partnerships are all welcome.
              </p>
              <ContactForm />
            </div>
          </div>
        </Section>
      </main>

      {/* =============================== FOOTER =============================== */}
      <footer className="bg-primary px-5 pt-16 pb-8 text-primary-foreground sm:px-8">
        <div className="mx-auto max-w-[80rem]">
          <div className="grid gap-10 md:grid-cols-4">
            <div className="md:col-span-2">
              <p className="font-display text-2xl font-semibold">{org.name}</p>
              <p className="mt-4 max-w-sm leading-relaxed text-primary-foreground/70">
                {org.tagline}
              </p>
              {[
                { label: "Instagram", href: org.instagram },
                { label: "Facebook", href: org.facebook },
                { label: "YouTube", href: org.youtube },
              ].some((s) => s.href) && (
                <div className="mt-6 flex gap-3">
                  {[
                    { label: "Instagram", href: org.instagram },
                    { label: "Facebook", href: org.facebook },
                    { label: "YouTube", href: org.youtube },
                  ].filter((s) => s.href).map((s) => (
                    <a
                      key={s.label}
                      href={s.href}
                      target="_blank"
                      rel="noreferrer"
                      className="rounded-full border border-primary-foreground/20 px-4 py-1.5 text-xs text-primary-foreground/70 hover:border-primary-foreground/50 hover:text-primary-foreground"
                    >
                      {s.label}
                    </a>
                  ))}
                </div>
              )}
            </div>

            <nav aria-label="Footer">
              <p className="text-xs font-semibold tracking-[0.2em] text-primary-foreground/50 uppercase">
                Quick links
              </p>
              <ul className="mt-4 space-y-2">
                {NAV_LINKS.map((l) => (
                  <li key={l.id}>
                    <a
                      href={`#${l.id}`}
                      className="text-primary-foreground/75 transition-colors hover:text-primary-foreground"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>

            <div>
              <p className="text-xs font-semibold tracking-[0.2em] text-primary-foreground/50 uppercase">
                Contact
              </p>
              <ul className="mt-4 space-y-2 text-primary-foreground/75">
                <li>{org.address}</li>
                <li>{org.addressSecondary}</li>
                <li>
                  <a href={`tel:${org.phone.replace(/\s/g, "")}`}>{org.phone}</a>
                </li>
                <li>
                  <a href={`tel:${org.phoneAlt.replace(/\s/g, "")}`}>{org.phoneAlt}</a>
                </li>
                <li>{org.contactPersons}</li>
                <li>{org.hours}</li>
              </ul>
            </div>
          </div>

          <div className="mt-12 flex flex-col gap-3 border-t border-primary-foreground/15 pt-6 text-sm text-primary-foreground/60 sm:flex-row sm:items-center sm:justify-between">
            <p>
              © {new Date().getFullYear()} {org.name}. All rights reserved.
            </p>
            <p>
              <a href="#contact" className="hover:text-primary-foreground">
                Contact & Privacy
              </a>
            </p>
          </div>
        </div>
      </footer>

      <BackToTop />
    </div>
  );
}
